const api = 'http://localhost:8100/';

export class Endpoints {
  public static produtos = api + 'produtos';
}
