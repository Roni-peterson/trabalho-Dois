export interface Produto {
  id?: number;
  name?: string;
  valor?: number;
  descricao?: string;
  imgUrl?: string;
}
